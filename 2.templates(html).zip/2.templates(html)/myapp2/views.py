from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    info = {"name": "subu", "place": "jodhpur"}
    return render(request,'index.html',info)
    #return HttpResponse("home")

def rumpun(request):
    return HttpResponse("rempun")

def capfirst(request):
    return HttpResponse("capfirst")
