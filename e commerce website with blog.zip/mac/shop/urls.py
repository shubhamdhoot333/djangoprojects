from shop import views
from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('', views.index,name='ShopHome'),
    path('about/', views.about,name='AboutUs'),
    path('contact/', views.contact,name='ContactUs'),
    path('tracker/', views.tracker,name='TrackingStatus'),
    path('search/', views.search,name='Search'),
    path('productview/<int:myid>', views.productview,name='Productview'),
    path('checkout/<int:myid>', views.checkout,name='Checkout'),
    path('cart/<int:m_id>', views.cart, name='cart'),
    path('delete/<int:m_id>',views.delete, name='delete'),
    path('order/',views.order,name='order'),


]
