from django.shortcuts import render
from django.http import HttpResponse
from .models import Product, Contact, Addtocart,Order

# Create your views here.

def index(request):
    pro = Product.objects.all()
    return render(request, 'shop/index.html', {'product': pro})


def about(request):
    return render(request, 'shop/about.html')


def contact(request):
    if request.method == 'POST':
        print(request)
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        text = request.POST.get('text', '')
        contact = Contact(name=name, email=email, text=text)
        contact.save()
    return render(request, 'shop/contact.html')


def tracker(request):
    return render(request, 'shop/tracker.html')


def search(request):
    return render(request, 'shop/search.html')


def productview(request, myid):
    # fatch the product to id
    product = Product.objects.filter(product_code=myid)
    return render(request, 'shop/productview.html', {'product': product[0]})


def checkout(request,myid):
    product = Product.objects.filter(product_code=myid)
    print(product)
    return render(request, 'shop/checkout.html',{ 'product':product })

def order(request):
        print(request.method)
        if request.method == 'POST':
            p_code = request.POST.get('product_code', '')
            name = request.POST.get('name', '')
            email = request.POST.get('email', '')
            address = request.POST.get('address', '')
            city = request.POST.get('city', '')
            number = request.POST.get('number', '')
            state = request.POST.get('state', '')


            order = Order(name=name, email=email,address=address,city=city,number=number,state=state, product_code=p_code)
            order.save()
        return render(request, 'shop/congress.html')

def cart(request, m_id):
    product = Product.objects.filter(product_code=m_id)
    p_name=product[0].product_name
    p_code = product[0].product_code
    p_category=product[0].category
    p_subcategory=product[0].subcategory
    p_price = product[0].price
    p_desc=product[0].desc
    p_pub_date=product[0].pub_date
    p_image = product[0].image
    addtocart = Addtocart(p_number=p_code,email='',product_name=p_name,category=p_category,subcategory=p_subcategory,price=p_price
                        ,desc=p_desc,pub_date=p_pub_date,image=p_image)
    addtocart.save()

    cartdata = Addtocart.objects.filter(email='Shubhamdhoot333@gmail.com')
    print(cartdata)
    return render(request, 'shop/addtocart.html',{ 'cartdata':cartdata } )

def delete(request ,m_id):

    Addtocart.objects.filter(p_number= m_id,email='Shubhamdhoot333@gmail.com').delete()
    pro = Product.objects.all()
    return render(request, 'shop/index.html', {'product': pro})

