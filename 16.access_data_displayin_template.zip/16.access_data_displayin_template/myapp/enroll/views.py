from django.shortcuts import render
from enroll .models import Student
# Create your views here.
def index(request):
    s_data=Student.objects.all()
    print(s_data)
    return render(request,'enroll/index.html' , {'student': s_data } )