from django.db import models

# Create your models here.
class Student(models.Model):
    s_fname = models.CharField(max_length=100)
    s_lname = models.CharField(max_length=100)
    s_rno =  models.IntegerField(max_length=100)
