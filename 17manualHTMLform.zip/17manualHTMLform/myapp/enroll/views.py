from django.shortcuts import render
from .models import Student
# Create your views here.
def index(request):
    if request.method == 'POST':
        fname = request.POST.get('fname', '')
        lname = request.POST.get('lname', '')
        print(fname,lname)
        contact = Student(fname=fname,lname=lname)
        contact.save()

    return render(request,'enroll/index.html')

def congress(request):
    return render(request, 'enroll/congress.html')