from django.contrib.auth.signals import user_logged_in, user_logged_out ,  user_login_failed
from django.contrib.auth.models import User
from django.dispatch import receiver

@receiver(user_logged_in, sender=User)
def login_success(sender , request , user, **kwargs):
    print("--------------------------------")
    print("login in signal.......")
    print("sender",sender)
    print("Request",request)
    print("User:",user)
    print("User:",user.email)
    print(f'kwargs:{kwargs}' )


#user_logged_in.connect(login_success,sender=User)

@receiver(user_logged_out, sender=User)
def log_out(sender , request , user, **kwargs):
    print("--------------------------------")
    print("login-out signal.......")
    print("sender",sender)
    print("Request",request)
    print("User:",user)
    print("User:",user.email)
    print(f'kwargs:{kwargs}' )


@receiver(user_login_failed)
def login_failed(sender , request , credentials , **kwargs):
    print("--------------------------------")
    print("login failed signal.......")
    print("sender",sender)
    print("credential",credentials )
    print("Request",request)
    print(f'kwargs:{kwargs}' )
