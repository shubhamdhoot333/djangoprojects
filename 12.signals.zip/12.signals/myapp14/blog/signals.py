from django.dispatch import Signal, receiver

# creating signals
notification = Signal(providing_args=["request", "user"])


# receiver function
@receiver(notification)
def sho_notification(sender, **kwargs):
    print(f'{kwargs}')
    print("notification")

