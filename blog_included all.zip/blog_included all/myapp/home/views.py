from django.shortcuts import render
from django.contrib import messages

# Create your views here.
from django.shortcuts import render, HttpResponse, redirect
from .models import Contact
from blog.models import Post
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import login as auth_login


# Create your views here.
def home(request):
    allpost = Post.objects.all()
    context = {'allpost': allpost}
    return render(request, 'home/home.html', context)


def contact(request):
    messages.success(request, 'Welcome to contact Page .')
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        text = request.POST['text']
        if len(name) < 2 or len(email) < 3 or len(phone) < 10 or len(text) < 4:
            messages.warning(request, "please fill the form currect")
        else:
            contact1 = Contact(name=name, email=email, phone=phone, content=text)
            contact1.save()
            messages.success(request, 'form submitted successfully.')
    return render(request, 'home/contact.html')


def about(request):
    return render(request, 'home/about.html')


def signup(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        myuser = User.objects.create_user(name, email, password)
        myuser.save()
        messages.success(request, "your account has  been successfully created ")
    else:
        return HttpResponse('404 not allowed ')

    return render(request, 'home/home.html')


def login(request):
    if request.method == 'POST':
        uname = request.POST['name']
        upassword = request.POST['password']
        user = authenticate(username=uname, password=upassword)
        if user is not None:
            print(user)
            auth_login(request, user)
            messages.success(request, "successfully login ")
            return redirect('home')
        else:
            messages.warning(request, "Invalied values try again  ")
            return redirect('home')
    return render(request, 'home/home.html')


def logout(request):
    if request.method == 'POST':
        auth_logout(request)
        messages.success(request, 'you are successfully outout')
    return render(request, 'home/about.html')
