from django.shortcuts import render,HttpResponse,redirect
from  .models import Post,BlogComment
# Create your views here.
def blogHome(request):
    allpost = Post.objects.all()
    context = { 'allpost': allpost }
    return render(request, 'blog/blog.html', context)
    #return HttpResponse('this is bloghome page')

def blogPost(request,slug):
    post = Post.objects.filter(slug=slug)
    comments = BlogComment.objects.filter(post=post)
    context={ 'post': post,'comment':comments }
    return render(request, 'blog/blogPost.html',context)
    #return HttpResponse(f'this is blog page:{slug}')



def postComment(request):
    if request.method =="POST":
       comment = request.POST.get("comment")
       user = request.user
       postSno =  request.POST.get("postSno")
       post = Post.objects.get(sno=postSno)
       comment = BlogComment(comment = comment , user = user ,post =post)
       comment.save()

    return redirect(f"/blog/{ post.slug }")