from django.shortcuts import render
from .models import Student

# Create your views here.

def home(request):
    #student_data = Student.objects.all()
    #student_data = Student.objects.filter(marks=100)
    #student_data = Student.objects.exclude(marks=100)
    #student_data = Student.objects.order_by('name')
    #student_data = Student.objects.order_by('id').reverse()
    #student_data = Student.objects.values('name')
    student_data = Student.objects.values('id', 'name' , name=True)
    print(student_data)
    return render(request,'student/home.html',{ 'students' : student_data })
