from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=100)
    roll = models.IntegerField(unique=True,null=False)
    city = models.CharField(max_length=100)
    marks = models.IntegerField(max_length=100)
    pass_date = models.DateField()