from django.http import HttpResponse


def index(request):
    return HttpResponse('''
                            <br><a href ="https://www.twitter.com/">twitter</a>
                            <br><a href ="https://www.google.com/">GOOGLE</a>
                            <br><a href ="https://www.youtube.com/">youtube</a>
                            <br><a href ="https://www.facebook.com/">facebook</a>
                            <br><a href ="https://www.instagram.com/">instagram</a>

                         ''')